package com.example.demo.dao;

import com.example.demo.db.DatabaseConnection;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class FoodDaoSQL {
    private static final Connection conn = DatabaseConnection.getConnection();

    public String getFoodName(int id){
        try{
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT food_name FROM food WHERE " +
                    "food_id = " + id);
            rs.next();
            return rs.getString(1);
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return "";
    }
}
