package com.example.demo.model;

import org.apache.catalina.User;

public class UserModel {
    private int id;
    private String name;
    private int age;

    public UserModel(int id, String name, int age) {
        this.id = id;
        this.name = name;
        this.age = age;
    }

    // Copy constructor - Kopirajuci konstruktor
    public UserModel(UserModel user){
        this.id = user.id;
        this.age = user.age;
        this.name = user.name;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }
}
