package com.example.demo.model.response;

import java.util.UUID;

public class LoginResponseModel {
    private boolean successful;
    private UUID userId;

    public LoginResponseModel(boolean successful, UUID userId) {
        this.successful = successful;
        this.userId = userId;
    }

    public LoginResponseModel(boolean successful) {
        this.successful = successful;
    }

    public boolean isSuccessful() {
        return successful;
    }

    public UUID getUserId() {
        return userId;
    }
}
