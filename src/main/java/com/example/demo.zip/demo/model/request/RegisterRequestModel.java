package com.example.demo.model.request;

public class RegisterRequestModel {
    private String name,username,password,email;

    public RegisterRequestModel(String name, String username, String password, String email) {
        this.name = name;
        this.username = username;
        this.password = password;
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getEmail() {
        return email;
    }

    // {
    //     "name": "string",
    //         "username": "string", // Unique, at least 3 chars
    //         "password": "string",
    //         "email": "string" // must be valid / Unique
    // }
}
