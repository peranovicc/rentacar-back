package com.example.demo.model;

import java.util.UUID;

public class FridgeFoodModel {
    private UUID id;
    private String name;
    private double kcal, proteins, carbohydrates, fat, mass;

    public FridgeFoodModel(UUID id, String name, double kcal, double proteins, double carbohydrates, double fat, double mass) {
        this.id = id;
        this.name = name;
        this.kcal = kcal;
        this.proteins = proteins;
        this.carbohydrates = carbohydrates;
        this.fat = fat;
        this.mass = mass;
    }

    public UUID getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getKcal() {
        return kcal;
    }

    public double getProteins() {
        return proteins;
    }

    public double getCarbohydrates() {
        return carbohydrates;
    }

    public double getFat() {
        return fat;
    }

    public double getMass() {
        return mass;
    }
}
