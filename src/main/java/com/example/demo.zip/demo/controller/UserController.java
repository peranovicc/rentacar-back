package com.example.demo.controller;

import com.example.demo.model.FridgeFoodModel;
import com.example.demo.model.request.LoginRequestModel;
import com.example.demo.model.request.RegisterRequestModel;
import com.example.demo.model.response.LoginResponseModel;
import com.example.demo.model.UserModel;
import com.example.demo.dao.FoodDaoSQL;
import com.example.demo.model.response.RegisterResponseModel;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@RestController
public class UserController {
    private static final FoodDaoSQL foodsql = new FoodDaoSQL();

    @GetMapping("/users/{id}")
    public UserModel getUserPathParam(@PathVariable("id") int userId){
        System.out.println("PATH");
        System.out.println(foodsql.getFoodName(1));

        return new UserModel(5,"Pera",23);
    }

    @GetMapping("/users")
    public UserModel getUserQueryParam(@RequestParam(value = "id") int userId){
        System.out.println("QUERY");
        return new UserModel(5,"Pera",23);
    }

    // @GetMapping("/login")
    // public LoginResponseModel login(){
    //     if(uspesno()){
    //         // return true;
    //         return new LoginResponseModel(true);
    //     }
    //     //else return false
    //     else return new LoginResponseModel(false);
    // }


    // @GetMapping("/food/{id}")
    // getFoodById  - Враћа конкретно, на основу id

    // @GetMapping("/food")
    // getFood  - Враћа сву храну (Колекција)

    // @GetMapping("/users/{id}")
    // getUserById  - Враћа конкретно, на основу id

    // @GetMapping("/login")
    // login - query params
    // - Враћа LoginResponseModel

    // metoda koja dodaje user-a u bazu
    // @PostMapping("/users")
    // public UserModel addUser(@RequestBody UserModel user){
    //     try{
    //         usersql.addUser(user);
    //         return new UserModel(user);
    //     }
    //     catch(Exception e){
    //         e.printStackTrace();
    //     }
    //     return new UserModel(-1,null,-1);
    // }

    @PostMapping("/login")
    public LoginResponseModel login(@RequestBody LoginRequestModel info){
        // userdao.login(info.getIdentification(),info.getPassword())
        return new LoginResponseModel(true, UUID.randomUUID()); // из базе
    }

    @PostMapping("/register")
    public RegisterResponseModel register(@RequestBody RegisterRequestModel user){
        // Валидација података
        // user.getName().length ...
        // return new RegisterResponseModel(false,"Nije validan email");
        // userdao.register()
        return new RegisterResponseModel(true,"Uspesno");
    }

    @GetMapping("/my-fridge")
    public List<FridgeFoodModel> getFridgeFood(@RequestParam(value = "userId") int userId){
        List<FridgeFoodModel> x = new ArrayList<>();
        x.add(new FridgeFoodModel(UUID.randomUUID(),"Pera",564,454,6,64,688));
        x.add(new FridgeFoodModel(UUID.randomUUID(),"dfgdf",254,345,344,4,434));
        return x;
    }

}
